#!/bin/bash

echo "Starting a local web server at http://localhost:8888/"
python -m SimpleHTTPServer 8888